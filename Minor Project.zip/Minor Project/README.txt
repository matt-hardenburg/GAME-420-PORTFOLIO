To launch game, double-click the "Minor Project.html" file. Alternatively, right click the file and select open.

The img folder contains all assets for the project. Don't peek inside if you don't want to be spoiled!

"Minor Project.html" must be located in the same folder as the "img" folder for images to load correctly.